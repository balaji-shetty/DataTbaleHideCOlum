from django.shortcuts import render

from student.models import Country, City, Student, Company

from django.http import HttpResponse
from django.views.generic import TemplateView,ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy


class StudentList(ListView):
    model = Student



class StudentListCreate(CreateView):
    model = Student
    fields = ['user', 'student_name', 'city', 'address', 'branch', 'education', 'experience']


    success_url = reverse_lazy('student1_list')

class StudentListUpdate(UpdateView):
    model = Student
    fields = ['user', 'student_name', 'city', 'address', 'branch']
    success_url = reverse_lazy('student1_list')


class StudentListDelete(DeleteView):
    model = Student
    success_url = reverse_lazy('student1_list')



def view_django(request):

    return render(request,'django.html',{})



def view_hello(request):

    return render(request,'hello.html',{})




def view_hello_20(request):   

    return render(request,'hello-20.html',{})



def view_record(request):

    stud_record = Student.objects.all()
    city_record = City.objects.all()

    # return render(request,'record.html',{'stud12':stud_record})
    return render(request,'record.html',{'stud12':stud_record,'city12':city_record})


